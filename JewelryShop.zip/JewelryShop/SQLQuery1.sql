
CREATE DATABASE JewelryDB

GO
-- First, drop the dependent tables
DROP TABLE IF EXISTS [dbo].[tbl_Cart];
DROP TABLE IF EXISTS [dbo].[tbl_Invoice];

-- Then, drop the primary tables
DROP TABLE IF EXISTS [dbo].[tbl_Jewelry];
DROP TABLE IF EXISTS [dbo].[tbl_User];

-- Re-create the tables
CREATE TABLE [dbo].[tbl_Jewelry](
    JewelryId varchar(50) PRIMARY KEY NOT NULL,
    JewelryName nvarchar (50) NOT NULL,
	[Description] varchar (250) NOT NULL,
	[Type] [nvarchar](50) NULL,
    [image] nvarchar (max) NULL,
	[Price] float NOT NULL,
    [Status] [bit] NULL,
);
GO

CREATE TABLE [dbo].[tbl_User](
    UserId varchar(50) PRIMARY KEY NOT NULL,
    FullName nvarchar (50) NOT NULL,
	[Password] int NOT NULL,
	[RoleID] [nvarchar](50) NULL,
    Gmail nvarchar (50) NOT NULL,
	[Address] [nvarchar](50) NULL,
	[Status] [bit] NULL,
);
GO

CREATE TABLE [dbo].[tbl_Cart] (
	CartId nvarchar (50) PRIMARY KEY,
    JewelryId VARCHAR(50) NOT NULL,
	UserId VARCHAR(50) NOT NULL,
    Price float NOT NULL,
    [TotalPrice] [float]NULL,
    Quantity int NOT NULL,
	[Image] nvarchar (max) NULL,
    
    -- Define foreign keys
    CONSTRAINT FK_Cart_User FOREIGN KEY (UserId) REFERENCES tbl_User(UserId),
    CONSTRAINT FK_Cart_Jewelry FOREIGN KEY (JewelryId) REFERENCES tbl_Jewelry(JewelryId)
);
GO

CREATE TABLE [dbo].[tbl_Invoice] (
    InvId nvarchar(50) PRIMARY KEY,
    UserId varchar(50) NOT NULL,
    [total] [float]NULL,
	[dateBuy] [datetime] NULL,
	[gmail] [nvarchar](50) NULL,
	[address] [nvarchar](50) NULL,
    -- Define foreign keys
    CONSTRAINT FK_Invoice_User FOREIGN KEY (UserId) REFERENCES tbl_User(UserId)
);
GO
INSERT INTO [dbo].[tbl_User] (UserId, FullName, [Password], [RoleID], Gmail, [Address],[status] )
VALUES 
('U001', 'John Doe', 1234, 'AD', 'johndoe@example.com', '123 Elm Street',1),
('U002', 'Jane Smith', 5678, 'US', 'janesmith@example.com', '456 Oak Avenue',1),
('U003', 'Alice Johnson', 9101, 'US', 'alicejohnson@example.com', '789 Pine Road',1),
('U004', 'Bob Brown', 1213, 'US', 'bobbrown@example.com', '321 Maple Lane',1),
('U005', 'Charlie White', 1415, 'US', 'charliewhite@example.com', '654 Cedar Boulevard',1);
GO
INSERT INTO tbl_Jewelry (JewelryId, JewelryName, Description, Type, image, Price, Status) VALUES ('aaa','aaaa', 'aaaa','aaa', 'aaaa', 2, 2)
select*from tbl_Jewelry
DELETE FROM tbl_Jewelry WHERE JewelryId='aaa';